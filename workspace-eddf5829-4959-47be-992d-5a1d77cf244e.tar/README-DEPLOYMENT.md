# Sistem Informasi Agenda Kota Tangerang Selatan

Aplikasi modern untuk mengelola agenda Walikota, Wakil Walikota, dan Sekda Kota Tangerang Selatan.

## 🚀 Cara Deploy/Publish Aplikasi

### 1. 🏆 DEPLOY KE VERCEL (Rekomendasi - Gratis & Mudah)

#### Langkah 1: Push ke GitHub
```bash
# Install Git jika belum
git init
git add .
git commit -m "Initial commit - Sistem Informasi Agenda"

# Buat repository baru di GitHub, kemudian:
git remote add origin https://github.com/username/nama-repo.git
git push -u origin main
```

#### Langkah 2: Deploy ke Vercel
1. Buka [vercel.com](https://vercel.com)
2. Login dengan GitHub
3. Klik "New Project"
4. Pilih repository GitHub Anda
5. Klik "Deploy"

**Vercel akan otomatis:**
- Build aplikasi Anda
- Deploy ke URL gratis (https://nama-app.vercel.app)
- Setup SSL certificate
- Auto-deploy setiap ada push ke main branch

### 2. 🐳 DEPLOY DOCKER (Untuk Server Sendiri)

#### Build Docker Image
```bash
# Buat Dockerfile
docker build -t sistem-agenda .
docker run -p 3000:3000 sistem-agenda
```

### 3. 🌐 DEPLOY KE PLATFORM LAIN

#### Netlify
```bash
# Install Netlify CLI
npm install -g netlify-cli

# Build
npm run build

# Deploy
netlify deploy --prod --dir=.next
```

#### Railway
```bash
# Install Railway CLI
npm install -g @railway/cli

# Login
railway login

# Deploy
railway up
```

#### Render.com
1. Push ke GitHub
2. Connect GitHub ke Render.com
3. Pilih "Web Service"
4. Setup build command: `npm run build`
5. Setup start command: `npm start`

## 📋 Konfigurasi Environment Variables

### Untuk Production
Setiap platform deployment membutuhkan environment variables:

```env
# Database
DATABASE_URL="file:./dev.db"

# App URL (sesuaikan dengan domain Anda)
NEXT_PUBLIC_APP_URL="https://domain-anda.com"
```

### Setup Database Production
```bash
# Generate Prisma Client
npx prisma generate

# Push schema ke database production
npx prisma db push

# Seed data user demo
npx tsx prisma/seed.ts
npx tsx prisma/sample-agenda.ts
```

## 🔧 Konfigurasi Tambahan

### Custom Domain
Setelah deploy, Anda bisa setup custom domain:

#### Vercel
1. Dashboard Vercel → Project → Settings → Domains
2. Tambahkan custom domain
3. Update DNS records

#### Platform Lain
- Update DNS A record ke IP server
- Setup SSL certificate (Let's Encrypt)

### Security untuk Production
1. **Ganti password demo:**
   ```sql
   UPDATE User SET password = 'password-baru' WHERE email = 'admin@tangsel.go.id';
   ```

2. **Setup environment variables:**
   - Jangan hardcode password
   - Gunakan database production (PostgreSQL/MySQL)

3. **Enable HTTPS:**
   - Semua platform modern sudah auto-HTTPS
   - Untuk self-hosted, gunakan Let's Encrypt

## 📱 Testing Production

1. **Buka URL deployment** Anda
2. **Test login** dengan akun demo:
   - Email: admin@tangsel.go.id
   - Password: admin123
3. **Test fitur:**
   - Tambah agenda
   - Upload file
   - View detail
   - Delete agenda

## 🛠 Troubleshooting

### Build Errors
```bash
# Clear cache
rm -rf .next
npm run build

# Reinstall dependencies
rm -rf node_modules package-lock.json
npm install
```

### Database Issues
```bash
# Reset database
npx prisma db push --force-reset

# Regenerate client
npx prisma generate
```

### Deployment Errors
1. Check logs di platform deployment
2. Pastikan environment variables sudah benar
3. Verify build script berjalan lokal

## 💰 Biaya Deployment

| Platform | Biaya | Limitasi |
|----------|-------|----------|
| **Vercel** | Gratis | 100GB bandwidth/month |
| Netlify | Gratis | 100GB bandwidth/month |
| Railway | $5/bulan | 500MB RAM |
| Render.com | Gratis | 750 hours/month |
| Self-hosted | Sesuai server | Tidak ada limitasi |

## 🎯 Rekomendasi

**Untuk Pemerintah Kota:**
1. Gunakan **Vercel** untuk development/testing
2. Untuk production, gunakan **self-hosted** di server pemerintah
3. Setup custom domain: `agenda.tangselkota.go.id`
4. Integrasi dengan sistem autentikasi pemerintah

## 📞 Support

Jika ada masalah deployment:
1. Check error logs
2. Verify environment variables
3. Test build lokal terlebih dahulu
4. Hubungi IT support pemerintah kota