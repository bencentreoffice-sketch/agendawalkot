# 🌟 SISTEM INFORMASI AGENDA KOTA TANGERANG SELATAN

Aplikasi modern untuk mengelola agenda Walikota, Wakil Walikota, dan Sekda Kota Tangerang Selatan.

## ✨ Fitur

- 🔐 **Login Modern** - Autentikasi user dengan role-based access
- 📊 **Dashboard Interaktif** - Statistik agenda dan manajemen data
- 📝 **Form Input Lengkap** - Tambah agenda dengan semua field yang dibutuhkan
- 📋 **CRUD Operations** - Create, Read, Update, Delete agenda
- 📁 **File Upload** - Upload PDF/JPG/PNG untuk dokumen agenda
- 📱 **Responsive Design** - Tampilan optimal di desktop dan mobile
- 🎨 **UI Modern** - Menggunakan shadcn/ui components

## 🚀 Quick Start

### Installation
```bash
# Clone repository
git clone https://github.com/username/sistem-agenda-tangsel.git
cd sistem-agenda-tangsel

# Install dependencies
npm install

# Setup database
npm run db:push
npm run db:generate

# Create demo users
npx tsx prisma/seed.ts

# Add sample data
npx tsx prisma/sample-agenda.ts

# Start development server
npm run dev
```

### Demo Accounts
- **Admin**: admin@tangsel.go.id / admin123
- **Walikota**: walikota@tangsel.go.id / admin123
- **Wakil Walikota**: wakil@tangsel.go.id / admin123
- **Sekda**: sekda@tangsel.go.id / admin123

## 🌐 Deployment

### Vercel (Recommended)
1. Push ke GitHub
2. Import repository ke Vercel
3. Set environment variables:
   - `DATABASE_URL=file:./dev.db`
   - `NODE_ENV=production`
4. Deploy! 🚀

### Netlify
1. Push ke GitHub
2. Import repository ke Netlify
3. Build command: `npm run build`
4. Publish directory: `.next`
5. Deploy! 🚀

### Railway/Render
1. Push ke GitHub
2. Import repository
3. Add PostgreSQL database
4. Set `DATABASE_URL`
5. Deploy! 🚀

📖 **Detailed deployment guide**: [DEPLOYMENT.md](./DEPLOYMENT.md)

## 📱 Screenshots

### Login Page
- Modern design dengan gradien background
- Form login yang clean dan user-friendly
- Demo account information

### Dashboard
- Statistik agenda (Total, Terjadwal, Selesai, Dibatalkan)
- Tabel agenda dengan informasi lengkap
- Aksi cepat untuk tambah, view, edit, delete

### Form Input
- Semua field yang dibutuhkan:
  - Tanggal, Waktu
  - Asal Undangan
  - Kegiatan
  - Lokasi/Tempat
  - Disposisi
  - Keterangan
  - Status
  - Upload file (PDF/JPG/PNG)

### Detail View
- Modal detail dengan informasi lengkap
- Tampilan yang terstruktur dan mudah dibaca
- Aksi untuk edit agenda

## 🛠 Tech Stack

- **Framework**: Next.js 15 with App Router
- **Language**: TypeScript 5
- **Styling**: Tailwind CSS 4
- **UI Components**: shadcn/ui
- **Database**: Prisma ORM with SQLite
- **Icons**: Lucide React
- **Date Handling**: date-fns

## 📁 Project Structure

```
src/
├── app/
│   ├── page.tsx              # Dashboard utama
│   ├── login/page.tsx        # Halaman login
│   └── api/
│       ├── auth/login/       # API autentikasi
│       └── agendas/          # API manajemen agenda
├── components/
│   ├── ui/                   # shadcn/ui components
│   ├── AgendaForm.tsx        # Form input agenda
│   └── AuthGuard.tsx         # Proteksi halaman
└── lib/
    └── db.ts                 # Database client
```

## 🔧 Development

### Available Scripts
```bash
npm run dev          # Start development server
npm run build        # Build for production
npm run start        # Start production server
npm run lint         # Run ESLint
npm run db:push      # Push database schema
npm run db:generate  # Generate Prisma client
```

### Database Management
```bash
# Reset database
npm run db:reset

# View database
npx prisma studio

# Create new migration
npx prisma migrate dev --name migration_name
```

## 🔒 Security Features

- Input validation dengan Zod
- File type dan size validation
- SQL injection prevention dengan Prisma
- XSS protection
- Environment variable management

## 📊 Features Detail

### Agenda Management
- ✅ Create agenda dengan semua field required
- ✅ View agenda dalam modal detail
- ✅ Edit agenda (prepared, needs implementation)
- ✅ Delete agenda dengan konfirmasi
- ✅ Status management (Terjadwal/Selesai/Dibatalkan)
- ✅ File upload untuk dokumen pendukung

### User Management
- ✅ Role-based access control
- ✅ Multiple user roles (Admin, Walikota, Wakil, Sekda)
- ✅ Secure login system
- ✅ Session management

### UI/UX
- ✅ Responsive design
- ✅ Loading states
- ✅ Error handling
- ✅ Success notifications
- ✅ Modern animations
- ✅ Dark mode support (ready)

## 🌟 Future Enhancements

- [ ] Email notifications untuk agenda
- [ ] Calendar integration
- [ ] Advanced filtering dan search
- [ ] Export to PDF/Excel
- [ ] Mobile app (React Native)
- [ ] Real-time updates dengan WebSocket
- [ ] Advanced reporting dashboard

## 🤝 Contributing

1. Fork repository
2. Create feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to branch (`git push origin feature/AmazingFeature`)
5. Open Pull Request

## 📞 Support

Jika Anda butuh bantuan:
- 📧 Email: support@tangsel.go.id
- 📱 WhatsApp: +62 812-3456-7890
- 📖 Documentation: [DEPLOYMENT.md](./DEPLOYMENT.md)

## 📄 License

MIT License - see [LICENSE](LICENSE) file for details.

---

🏛️ **Pemerintah Kota Tangerang Selatan**  
© 2024 Sistem Informasi Agenda Resmi