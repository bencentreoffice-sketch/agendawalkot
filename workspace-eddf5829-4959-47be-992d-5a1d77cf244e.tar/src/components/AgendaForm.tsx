'use client'

import { useState, useRef } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { X, Upload, Calendar, Clock, MapPin, FileText, Send } from 'lucide-react'

interface AgendaFormProps {
  onClose: () => void
  onSuccess: () => void
  agenda?: any
}

export default function AgendaForm({ onClose, onSuccess, agenda }: AgendaFormProps) {
  const [formData, setFormData] = useState({
    tanggal: '',
    waktu: '',
    asalUndangan: '',
    kegiatan: '',
    lokasi: '',
    disposisi: '',
    keterangan: '',
    status: 'terjadwal'
  })
  const [file, setFile] = useState<File | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }))
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0]
    if (selectedFile) {
      // Check file type
      const allowedTypes = ['application/pdf', 'image/jpeg', 'image/jpg', 'image/png']
      if (!allowedTypes.includes(selectedFile.type)) {
        setError('Hanya file PDF, JPG, dan PNG yang diperbolehkan')
        return
      }

      // Check file size (max 5MB)
      if (selectedFile.size > 5 * 1024 * 1024) {
        setError('Ukuran file maksimal 5MB')
        return
      }

      setFile(selectedFile)
      setError('')
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError('')

    try {
      const formDataToSend = new FormData()
      
      // Add form fields
      Object.entries(formData).forEach(([key, value]) => {
        formDataToSend.append(key, value)
      })

      // Add file if exists
      if (file) {
        formDataToSend.append('file', file)
      }

      // Get user data from localStorage
      const userStr = localStorage.getItem('user')
      const user = userStr ? JSON.parse(userStr) : null

      const response = await fetch('/api/agendas', {
        method: 'POST',
        headers: {
          'x-user-data': userStr || ''
        },
        body: formDataToSend,
      })

      const data = await response.json()

      if (response.ok) {
        onSuccess()
        onClose()
      } else {
        setError(data.message || 'Gagal menyimpan agenda')
      }
    } catch (error) {
      setError('Terjadi kesalahan. Silakan coba lagi.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <Card className="border-0 shadow-none">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle className="flex items-center">
                <Calendar className="w-5 h-5 mr-2 text-red-600" />
                {agenda ? 'Edit Agenda' : 'Tambah Agenda Baru'}
              </CardTitle>
              <CardDescription>
                Isi formulir berikut untuk menambahkan agenda kegiatan
              </CardDescription>
            </div>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="w-4 h-4" />
            </Button>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {error && (
                <Alert variant="destructive">
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="tanggal">
                    <Calendar className="w-4 h-4 inline mr-1" />
                    Tanggal
                  </Label>
                  <Input
                    id="tanggal"
                    type="date"
                    value={formData.tanggal}
                    onChange={(e) => handleInputChange('tanggal', e.target.value)}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="waktu">
                    <Clock className="w-4 h-4 inline mr-1" />
                    Waktu
                  </Label>
                  <Input
                    id="waktu"
                    type="time"
                    value={formData.waktu}
                    onChange={(e) => handleInputChange('waktu', e.target.value)}
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="asalUndangan">Asal Undangan</Label>
                <Input
                  id="asalUndangan"
                  placeholder="Contoh: Dinas Pendidikan"
                  value={formData.asalUndangan}
                  onChange={(e) => handleInputChange('asalUndangan', e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="kegiatan">Kegiatan</Label>
                <Textarea
                  id="kegiatan"
                  placeholder="Deskripsi kegiatan yang akan dilaksanakan"
                  value={formData.kegiatan}
                  onChange={(e) => handleInputChange('kegiatan', e.target.value)}
                  rows={3}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="lokasi">
                  <MapPin className="w-4 h-4 inline mr-1" />
                  Lokasi/Tempat
                </Label>
                <Input
                  id="lokasi"
                  placeholder="Contoh: Ruang Rapat Walikota"
                  value={formData.lokasi}
                  onChange={(e) => handleInputChange('lokasi', e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="disposisi">Disposisi</Label>
                <Input
                  id="disposisi"
                  placeholder="Contoh: Walikota, Wakil Walikota, Sekda"
                  value={formData.disposisi}
                  onChange={(e) => handleInputChange('disposisi', e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="keterangan">Keterangan</Label>
                <Textarea
                  id="keterangan"
                  placeholder="Keterangan tambahan (opsional)"
                  value={formData.keterangan}
                  onChange={(e) => handleInputChange('keterangan', e.target.value)}
                  rows={2}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="status">Status</Label>
                <Select value={formData.status} onValueChange={(value) => handleInputChange('status', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Pilih status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="terjadwal">Terjadwal</SelectItem>
                    <SelectItem value="selesai">Selesai</SelectItem>
                    <SelectItem value="dibatalkan">Dibatalkan</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="file">
                  <FileText className="w-4 h-4 inline mr-1" />
                  Upload Dokumen (PDF/JPG/PNG)
                </Label>
                <div className="flex items-center space-x-2">
                  <Input
                    id="file"
                    type="file"
                    ref={fileInputRef}
                    onChange={handleFileChange}
                    accept=".pdf,.jpg,.jpeg,.png"
                    className="hidden"
                  />
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => fileInputRef.current?.click()}
                    className="flex items-center space-x-2"
                  >
                    <Upload className="w-4 h-4" />
                    <span>Pilih File</span>
                  </Button>
                  {file && (
                    <span className="text-sm text-gray-600">
                      {file.name} ({(file.size / 1024 / 1024).toFixed(2)} MB)
                    </span>
                  )}
                </div>
                <p className="text-xs text-gray-500">
                  Maksimal ukuran file 5MB. Format: PDF, JPG, PNG
                </p>
              </div>

              <div className="flex justify-end space-x-2 pt-4">
                <Button type="button" variant="outline" onClick={onClose}>
                  Batal
                </Button>
                <Button
                  type="submit"
                  className="bg-red-600 hover:bg-red-700"
                  disabled={loading}
                >
                  {loading ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                      Menyimpan...
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4 mr-2" />
                      Simpan Agenda
                    </>
                  )}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}