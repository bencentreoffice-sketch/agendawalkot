import type { Metadata } from "next";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

export const metadata: Metadata = {
  title: "Sistem Informasi Agenda - Kota Tangerang Selatan",
  description: "Sistem Informasi Agenda resmi untuk Walikota, Wakil Walikota, dan Sekda Kota Tangerang Selatan",
  keywords: ["Agenda", "Tangerang Selatan", "Pemerintah", "Sistem Informasi"],
  authors: [{ name: "Pemerintah Kota Tangerang Selatan" }],
  icons: {
    icon: "/favicon.ico",
  },
  openGraph: {
    title: "Sistem Informasi Agenda - Kota Tangerang Selatan",
    description: "Sistem Informasi Agenda resmi untuk Pemerintah Kota Tangerang Selatan",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Sistem Informasi Agenda - Kota Tangerang Selatan",
    description: "Sistem Informasi Agenda resmi untuk Pemerintah Kota Tangerang Selatan",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="id" suppressHydrationWarning>
      <body className="antialiased bg-background text-foreground font-sans">
        {children}
        <Toaster />
      </body>
    </html>
  );
}
