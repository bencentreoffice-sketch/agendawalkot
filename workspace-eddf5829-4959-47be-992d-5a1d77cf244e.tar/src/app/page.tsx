'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Label } from '@/components/ui/label'
import { Calendar, Clock, MapPin, Users, FileText, Plus, Eye, Edit, Trash2, LogOut, X } from 'lucide-react'
import { format } from 'date-fns'
import { id } from 'date-fns/locale'
import AgendaForm from '@/components/AgendaForm'
import AuthGuard from '@/components/AuthGuard'

interface Agenda {
  id: string
  tanggal: string
  waktu: string
  asalUndangan: string
  kegiatan: string
  lokasi: string
  disposisi?: string
  keterangan?: string
  status: string
  createdAt: string
}

function DashboardContent() {
  const [agendas, setAgendas] = useState<Agenda[]>([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [selectedAgenda, setSelectedAgenda] = useState<Agenda | null>(null)

  useEffect(() => {
    fetchAgendas()
  }, [])

  const fetchAgendas = async () => {
    try {
      const response = await fetch('/api/agendas')
      if (response.ok) {
        const data = await response.json()
        setAgendas(data)
      }
    } catch (error) {
      console.error('Error fetching agendas:', error)
    } finally {
      setLoading(false)
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'terjadwal': return 'bg-blue-100 text-blue-800'
      case 'selesai': return 'bg-green-100 text-green-800'
      case 'dibatalkan': return 'bg-red-100 text-red-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case 'terjadwal': return 'Terjadwal'
      case 'selesai': return 'Selesai'
      case 'dibatalkan': return 'Dibatalkan'
      default: return status
    }
  }

  const handleViewAgenda = (agenda: Agenda) => {
    setSelectedAgenda(agenda)
  }

  const handleDeleteAgenda = async (id: string) => {
    if (!confirm('Apakah Anda yakin ingin menghapus agenda ini?')) {
      return
    }

    try {
      const response = await fetch(`/api/agendas/${id}`, {
        method: 'DELETE'
      })

      if (response.ok) {
        fetchAgendas()
      } else {
        alert('Gagal menghapus agenda')
      }
    } catch (error) {
      console.error('Error deleting agenda:', error)
      alert('Terjadi kesalahan. Silakan coba lagi.')
    }
  }

  const handleLogout = () => {
    localStorage.removeItem('user')
    window.location.href = '/login'
  }

  const handleAgendaSuccess = () => {
    fetchAgendas()
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-red-600 rounded-lg flex items-center justify-center">
                  <Calendar className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-gray-900">
                    Sistem Informasi Agenda
                  </h1>
                  <p className="text-xs text-gray-500">
                    Pemerintah Kota Tangerang Selatan
                  </p>
                </div>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Button
                variant="outline"
                size="sm"
                onClick={handleLogout}
                className="flex items-center space-x-2"
              >
                <LogOut className="w-4 h-4" />
                <span>Keluar</span>
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Agenda</p>
                  <p className="text-2xl font-bold text-gray-900">{agendas.length}</p>
                </div>
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Calendar className="w-6 h-6 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Terjadwal</p>
                  <p className="text-2xl font-bold text-blue-600">
                    {agendas.filter(a => a.status === 'terjadwal').length}
                  </p>
                </div>
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Clock className="w-6 h-6 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Selesai</p>
                  <p className="text-2xl font-bold text-green-600">
                    {agendas.filter(a => a.status === 'selesai').length}
                  </p>
                </div>
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                  <FileText className="w-6 h-6 text-green-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Dibatalkan</p>
                  <p className="text-2xl font-bold text-red-600">
                    {agendas.filter(a => a.status === 'dibatalkan').length}
                  </p>
                </div>
                <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                  <Trash2 className="w-6 h-6 text-red-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Agenda List */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Daftar Agenda</CardTitle>
              <CardDescription>
                Kelola agenda Walikota, Wakil Walikota, dan Sekda Kota Tangerang Selatan
              </CardDescription>
            </div>
            <Button
              onClick={() => setShowForm(true)}
              className="bg-red-600 hover:bg-red-700"
            >
              <Plus className="w-4 h-4 mr-2" />
              Tambah Agenda
            </Button>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="text-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-red-600 mx-auto"></div>
                <p className="mt-2 text-gray-500">Memuat data...</p>
              </div>
            ) : agendas.length === 0 ? (
              <div className="text-center py-8">
                <Calendar className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">Belum ada agenda</p>
                <Button
                  onClick={() => setShowForm(true)}
                  variant="outline"
                  className="mt-4"
                >
                  Tambah Agenda Pertama
                </Button>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-3 px-4 font-medium text-gray-700">No</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-700">Kegiatan</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-700">Tanggal</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-700">Waktu</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-700">Lokasi</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-700">Status</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-700">Aksi</th>
                    </tr>
                  </thead>
                  <tbody>
                    {agendas.map((agenda, index) => (
                      <tr key={agenda.id} className="border-b hover:bg-gray-50">
                        <td className="py-3 px-4">{index + 1}</td>
                        <td className="py-3 px-4">
                          <div>
                            <p className="font-medium text-gray-900">{agenda.kegiatan}</p>
                            <p className="text-sm text-gray-500">{agenda.asalUndangan}</p>
                          </div>
                        </td>
                        <td className="py-3 px-4">
                          {format(new Date(agenda.tanggal), 'dd MMMM yyyy', { locale: id })}
                        </td>
                        <td className="py-3 px-4">{agenda.waktu}</td>
                        <td className="py-3 px-4">
                          <div className="flex items-center text-gray-600">
                            <MapPin className="w-4 h-4 mr-1" />
                            {agenda.lokasi}
                          </div>
                        </td>
                        <td className="py-3 px-4">
                          <Badge className={getStatusColor(agenda.status)}>
                            {getStatusText(agenda.status)}
                          </Badge>
                        </td>
                        <td className="py-3 px-4">
                          <div className="flex space-x-2">
                            <Button 
                              variant="outline" 
                              size="sm"
                              onClick={() => handleViewAgenda(agenda)}
                            >
                              <Eye className="w-4 h-4" />
                            </Button>
                            <Button variant="outline" size="sm">
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button 
                              variant="outline" 
                              size="sm"
                              onClick={() => handleDeleteAgenda(agenda.id)}
                              className="text-red-600 hover:text-red-700"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </main>

      {/* Agenda Form Modal */}
      {showForm && (
        <AgendaForm
          onClose={() => setShowForm(false)}
          onSuccess={handleAgendaSuccess}
        />
      )}

      {/* Agenda Detail Modal */}
      {selectedAgenda && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex justify-between items-start mb-6">
                <div>
                  <h2 className="text-2xl font-bold text-gray-900 mb-2">Detail Agenda</h2>
                  <Badge className={getStatusColor(selectedAgenda.status)}>
                    {getStatusText(selectedAgenda.status)}
                  </Badge>
                </div>
                <Button variant="ghost" size="sm" onClick={() => setSelectedAgenda(null)}>
                  <X className="w-4 h-4" />
                </Button>
              </div>

              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Label className="text-sm font-medium text-gray-500">Tanggal</Label>
                    <p className="text-lg font-semibold text-gray-900">
                      {format(new Date(selectedAgenda.tanggal), 'dd MMMM yyyy', { locale: id })}
                    </p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-500">Waktu</Label>
                    <p className="text-lg font-semibold text-gray-900">{selectedAgenda.waktu}</p>
                  </div>
                </div>

                <div>
                  <Label className="text-sm font-medium text-gray-500">Asal Undangan</Label>
                  <p className="text-lg font-semibold text-gray-900">{selectedAgenda.asalUndangan}</p>
                </div>

                <div>
                  <Label className="text-sm font-medium text-gray-500">Kegiatan</Label>
                  <p className="text-lg text-gray-900 whitespace-pre-wrap">{selectedAgenda.kegiatan}</p>
                </div>

                <div>
                  <Label className="text-sm font-medium text-gray-500">Lokasi/Tempat</Label>
                  <div className="flex items-center text-gray-900">
                    <MapPin className="w-4 h-4 mr-2 text-red-600" />
                    <span className="text-lg">{selectedAgenda.lokasi}</span>
                  </div>
                </div>

                {selectedAgenda.disposisi && (
                  <div>
                    <Label className="text-sm font-medium text-gray-500">Disposisi</Label>
                    <p className="text-lg text-gray-900">{selectedAgenda.disposisi}</p>
                  </div>
                )}

                {selectedAgenda.keterangan && (
                  <div>
                    <Label className="text-sm font-medium text-gray-500">Keterangan</Label>
                    <p className="text-lg text-gray-900 whitespace-pre-wrap">{selectedAgenda.keterangan}</p>
                  </div>
                )}

                <div>
                  <Label className="text-sm font-medium text-gray-500">Dibuat pada</Label>
                  <p className="text-lg text-gray-900">
                    {format(new Date(selectedAgenda.createdAt), 'dd MMMM yyyy HH:mm', { locale: id })}
                  </p>
                </div>
              </div>

              <div className="flex justify-end space-x-2 mt-8 pt-6 border-t">
                <Button variant="outline" onClick={() => setSelectedAgenda(null)}>
                  Tutup
                </Button>
                <Button className="bg-red-600 hover:bg-red-700">
                  <Edit className="w-4 h-4 mr-2" />
                  Edit Agenda
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default function Home() {
  return (
    <AuthGuard>
      <DashboardContent />
    </AuthGuard>
  )
}