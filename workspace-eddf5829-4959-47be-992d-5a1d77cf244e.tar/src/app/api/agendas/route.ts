import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { writeFile, mkdir } from 'fs/promises'
import { join } from 'path'

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    
    // Extract form fields
    const tanggal = formData.get('tanggal') as string
    const waktu = formData.get('waktu') as string
    const asalUndangan = formData.get('asalUndangan') as string
    const kegiatan = formData.get('kegiatan') as string
    const lokasi = formData.get('lokasi') as string
    const disposisi = formData.get('disposisi') as string
    const keterangan = formData.get('keterangan') as string
    const status = formData.get('status') as string
    const file = formData.get('file') as File | null
    
    // Get user from localStorage (in production, use proper session management)
    const userStr = request.headers.get('x-user-data')
    let createdBy = 'default-user' // fallback
    
    if (userStr) {
      try {
        const user = JSON.parse(userStr)
        createdBy = user.id
      } catch (e) {
        console.error('Error parsing user data:', e)
      }
    }

    // Validate required fields
    if (!tanggal || !waktu || !asalUndangan || !kegiatan || !lokasi) {
      return NextResponse.json(
        { message: 'Semua field wajib harus diisi' },
        { status: 400 }
      )
    }

    let fileUrl = null
    let fileName = null
    let fileType = null

    // Handle file upload
    if (file) {
      const bytes = await file.arrayBuffer()
      const buffer = Buffer.from(bytes)

      // Create uploads directory if it doesn't exist
      const uploadsDir = join(process.cwd(), 'public', 'uploads')
      try {
        await mkdir(uploadsDir, { recursive: true })
      } catch (error) {
        console.error('Error creating uploads directory:', error)
      }

      // Generate unique filename
      const timestamp = Date.now()
      const originalName = file.name.replace(/[^a-zA-Z0-9.-]/g, '_')
      const uniqueFileName = `${timestamp}_${originalName}`
      const filePath = join(uploadsDir, uniqueFileName)

      // Write file
      await writeFile(filePath, buffer)
      
      fileUrl = `/uploads/${uniqueFileName}`
      fileName = file.name
      fileType = file.type
    }

    // Create agenda in database
    const agenda = await db.agenda.create({
      data: {
        tanggal: new Date(tanggal),
        waktu,
        asalUndangan,
        kegiatan,
        lokasi,
        disposisi: disposisi || null,
        keterangan: keterangan || null,
        status: status || 'terjadwal',
        fileUrl,
        fileName,
        fileType,
        createdBy
      }
    })

    return NextResponse.json({
      message: 'Agenda berhasil dibuat',
      agenda
    })

  } catch (error) {
    console.error('Error creating agenda:', error)
    return NextResponse.json(
      { message: 'Terjadi kesalahan server' },
      { status: 500 }
    )
  }
}

export async function GET() {
  try {
    const agendas = await db.agenda.findMany({
      include: {
        creator: {
          select: {
            id: true,
            name: true,
            email: true,
            role: true
          }
        }
      },
      orderBy: {
        createdAt: 'desc'
      }
    })

    return NextResponse.json(agendas)

  } catch (error) {
    console.error('Error fetching agendas:', error)
    return NextResponse.json(
      { message: 'Terjadi kesalahan server' },
      { status: 500 }
    )
  }
}