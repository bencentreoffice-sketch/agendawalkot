import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { id } = params

    // Check if agenda exists
    const agenda = await db.agenda.findUnique({
      where: { id }
    })

    if (!agenda) {
      return NextResponse.json(
        { message: 'Agenda tidak ditemukan' },
        { status: 404 }
      )
    }

    // Delete agenda
    await db.agenda.delete({
      where: { id }
    })

    return NextResponse.json({
      message: 'Agenda berhasil dihapus'
    })

  } catch (error) {
    console.error('Error deleting agenda:', error)
    return NextResponse.json(
      { message: 'Terjadi kesalahan server' },
      { status: 500 }
    )
  }
}