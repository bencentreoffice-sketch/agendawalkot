const { execSync } = require('child_process');
const readline = require('readline');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

console.log('🚀 SISTEM INFORMASI AGENDA - KOTA TANGERANG SELATAN');
console.log('==================================================');
console.log('');

console.log('Pilih metode deployment:');
console.log('1) Vercel (Rekomendasi - Gratis & Mudah)');
console.log('2) Docker (Untuk Server Sendiri)');
console.log('3) Build Static (Untuk hosting lain)');
console.log('4) Local Production');
console.log('');

rl.question('Masukkan pilihan (1-4): ', (choice) => {
  switch (choice) {
    case '1':
      console.log('');
      console.log('📋 DEPLOY KE VERCEL');
      console.log('===================');
      console.log('');
      console.log('Langkah 1: Push ke GitHub');
      console.log('-------------------------');
      
      try {
        // Check if git is initialized
        execSync('git status', { stdio: 'ignore' });
        console.log('✅ Git repository already exists');
        console.log('Run: git push origin main');
      } catch (error) {
        console.log('Initializing git repository...');
        execSync('git init', { stdio: 'inherit' });
        execSync('git add .', { stdio: 'inherit' });
        execSync('git commit -m "Initial commit - Sistem Informasi Agenda"', { stdio: 'inherit' });
        console.log('');
        console.log('✅ Git repository initialized!');
        console.log('');
        console.log('📝 Langkah berikutnya:');
        console.log('1. Buat repository baru di GitHub: https://github.com/new');
        console.log('2. Run: git remote add origin https://github.com/username/nama-repo.git');
        console.log('3. Run: git push -u origin main');
        console.log('4. Buka vercel.com dan deploy repository Anda');
      }
      break;
      
    case '2':
      console.log('');
      console.log('🐳 DEPLOY DOCKER');
      console.log('===============');
      console.log('');
      
      try {
        console.log('🔨 Building Docker image...');
        execSync('docker build -t sistem-agenda .', { stdio: 'inherit' });
        console.log('✅ Docker image built successfully!');
        console.log('');
        console.log('🚀 Starting container...');
        execSync('docker run -d -p 3000:3000 --name agenda-app sistem-agenda', { stdio: 'inherit' });
        console.log('✅ Container started successfully!');
        console.log('🌐 Aplikasi berjalan di: http://localhost:3000');
      } catch (error) {
        console.log('❌ Docker deployment failed. Make sure Docker is installed and running.');
      }
      break;
      
    case '3':
      console.log('');
      console.log('📦 BUILD STATIC');
      console.log('==============');
      console.log('');
      
      try {
        console.log('📦 Installing dependencies...');
        execSync('npm install', { stdio: 'inherit' });
        
        console.log('🔨 Building application...');
        execSync('npm run build', { stdio: 'inherit' });
        
        console.log('✅ Build successful!');
        console.log('');
        console.log('📁 Output folder: .next');
        console.log('');
        console.log('📝 Langkah berikutnya:');
        console.log('1. Upload folder .next ke hosting Anda');
        console.log('2. Setup environment variables');
        console.log('3. Run: npm start');
      } catch (error) {
        console.log('❌ Build failed');
      }
      break;
      
    case '4':
      console.log('');
      console.log('💻 LOCAL PRODUCTION');
      console.log('===================');
      console.log('');
      
      try {
        console.log('📦 Installing dependencies...');
        execSync('npm install', { stdio: 'inherit' });
        
        console.log('🔨 Building application...');
        execSync('npm run build', { stdio: 'inherit' });
        
        console.log('✅ Build successful!');
        console.log('');
        console.log('🚀 Starting production server...');
        execSync('npm start', { stdio: 'inherit' });
      } catch (error) {
        console.log('❌ Local production setup failed');
      }
      break;
      
    default:
      console.log('❌ Pilihan tidak valid!');
      rl.close();
      return;
  }
  
  console.log('');
  console.log('📚 Informasi Login:');
  console.log('==================');
  console.log('Email: admin@tangsel.go.id');
  console.log('Password: admin123');
  console.log('');
  console.log('📞 Jika ada masalah, cek README-DEPLOYMENT.md');
  
  rl.close();
});