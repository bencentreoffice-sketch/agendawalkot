#!/bin/bash

# 🚀 Deployment Script for Sistem Informasi Agenda

echo "🌟 SISTEM INFORMASI AGENDA - DEPLOYMENT SCRIPT"
echo "============================================"

# Check if git is initialized
if [ ! -d ".git" ]; then
    echo "📦 Initializing Git repository..."
    git init
    git add .
    git commit -m "Initial commit - Sistem Informasi Agenda Kota Tangerang Selatan"
    echo "✅ Git repository initialized!"
else
    echo "✅ Git repository already exists"
fi

# Check if remote is set
if ! git remote get-url origin > /dev/null 2>&1; then
    echo "🔗 Please set your GitHub remote:"
    echo "git remote add origin https://github.com/username/sistem-agenda-tangsel.git"
    echo ""
    echo "Then run this script again!"
    exit 1
fi

echo ""
echo "🚀 Ready to deploy! Choose your platform:"
echo "1) Vercel (Recommended - Free)"
echo "2) Netlify (Alternative - Free)"
echo "3) Railway (With Database - Paid)"
echo "4) Local Production Test"
echo ""

read -p "Choose option (1-4): " choice

case $choice in
    1)
        echo "🌐 Deploying to Vercel..."
        echo "📋 Steps:"
        echo "1. Push to GitHub: git push -u origin main"
        echo "2. Go to vercel.com"
        echo "3. Import your GitHub repository"
        echo "4. Click Deploy"
        echo ""
        echo "🔧 Environment Variables needed:"
        echo "- DATABASE_URL: file:./dev.db"
        echo "- NODE_ENV: production"
        ;;
    2)
        echo "🌐 Deploying to Netlify..."
        echo "📋 Steps:"
        echo "1. Push to GitHub: git push -u origin main"
        echo "2. Go to netlify.com"
        echo "3. Import your GitHub repository"
        echo "4. Build command: npm run build"
        echo "5. Publish directory: .next"
        echo "6. Click Deploy site"
        ;;
    3)
        echo "🌐 Deploying to Railway..."
        echo "📋 Steps:"
        echo "1. Push to GitHub: git push -u origin main"
        echo "2. Go to railway.app"
        echo "3. Import your GitHub repository"
        echo "4. Add PostgreSQL database"
        echo "5. Set DATABASE_URL"
        echo "6. Deploy!"
        ;;
    4)
        echo "🧪 Running local production test..."
        npm run build
        echo "✅ Build successful!"
        echo "🚀 Starting production server..."
        echo "📝 Open http://localhost:3000"
        npm start
        ;;
    *)
        echo "❌ Invalid option!"
        exit 1
        ;;
esac

echo ""
echo "✨ Deployment guide created! Check DEPLOYMENT.md for detailed instructions."
echo "📞 Need help? Check the documentation or contact support."