import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

async function main() {
  // Get the admin user
  const adminUser = await prisma.user.findUnique({
    where: { email: 'admin@tangsel.go.id' }
  })

  if (!adminUser) {
    console.log('Admin user not found. Please run seed first.')
    return
  }

  // Create sample agendas
  const sampleAgendas = [
    {
      tanggal: new Date('2024-06-04'),
      waktu: '09:00',
      asalUndangan: 'Dinas Pendidikan',
      kegiatan: 'Rapat Koordinasi Persiapan Ujian Sekolah',
      lokasi: 'Ruang Rapat Walikota',
      disposisi: 'Walikota, Sekda',
      keterangan: 'Membahas persiapan ujian sekolah untuk tahun ajaran 2024/2025',
      status: 'terjadwal',
      createdBy: adminUser.id
    },
    {
      tanggal: new Date('2024-06-05'),
      waktu: '10:00',
      asalUndangan: 'Dinas Kesehatan',
      kegiatan: 'Peluncuran Program Vaksinasi Gratis',
      lokasi: 'Auditorium Pemerintah Kota',
      disposisi: 'Walikota, Wakil Walikota',
      keterangan: 'Peluncuran program vaksinasi gratis untuk masyarakat',
      status: 'terjadwal',
      createdBy: adminUser.id
    },
    {
      tanggal: new Date('2024-06-03'),
      waktu: '13:00',
      asalUndangan: 'Dinas Pekerjaan Umum',
      kegiatan: 'Peninjauan Proyek Infrastruktur Jalan',
      lokasi: 'Kecamatan Serpong',
      disposisi: 'Wakil Walikota',
      keterangan: 'Meninjau perkembangan proyek pembangunan jalan',
      status: 'selesai',
      createdBy: adminUser.id
    },
    {
      tanggal: new Date('2024-06-06'),
      waktu: '14:00',
      asalUndangan: 'Badan Perencanaan Pembangunan Daerah',
      kegiatan: 'Presentasi Rencana Pembangunan 2025',
      lokasi: 'Ruang Rapat Sekda',
      disposisi: 'Sekda',
      keterangan: 'Presentasi rencana pembangunan tahun 2025',
      status: 'terjadwal',
      createdBy: adminUser.id
    }
  ]

  for (const agenda of sampleAgendas) {
    await prisma.agenda.create({
      data: agenda
    })
  }

  console.log('Sample agendas created successfully!')
}

main()
  .then(async () => {
    await prisma.$disconnect()
  })
  .catch(async (e) => {
    console.error(e)
    await prisma.$disconnect()
    process.exit(1)
  })