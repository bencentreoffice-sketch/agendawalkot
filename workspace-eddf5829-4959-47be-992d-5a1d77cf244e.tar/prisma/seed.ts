import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

async function main() {
  // Create demo admin user with plain password (for demo only)
  const adminUser = await prisma.user.upsert({
    where: { email: 'admin@tangsel.go.id' },
    update: {},
    create: {
      email: 'admin@tangsel.go.id',
      name: 'Administrator',
      role: 'admin',
      password: 'admin123', // Plain text for demo only
    },
  })

  // Create demo users for different roles
  const walikotaUser = await prisma.user.upsert({
    where: { email: 'walikota@tangsel.go.id' },
    update: {},
    create: {
      email: 'walikota@tangsel.go.id',
      name: 'Walikota Tangerang Selatan',
      role: 'walikota',
      password: 'admin123',
    },
  })

  const wakilWalikotaUser = await prisma.user.upsert({
    where: { email: 'wakil@tangsel.go.id' },
    update: {},
    create: {
      email: 'wakil@tangsel.go.id',
      name: 'Wakil Walikota Tangerang Selatan',
      role: 'wakil_walikota',
      password: 'admin123',
    },
  })

  const sekdaUser = await prisma.user.upsert({
    where: { email: 'sekda@tangsel.go.id' },
    update: {},
    create: {
      email: 'sekda@tangsel.go.id',
      name: 'Sekretaris Daerah',
      role: 'sekda',
      password: 'admin123',
    },
  })

  console.log('Demo users created:')
  console.log('Admin: admin@tangsel.go.id / admin123')
  console.log('Walikota: walikota@tangsel.go.id / admin123')
  console.log('Wakil Walikota: wakil@tangsel.go.id / admin123')
  console.log('Sekda: sekda@tangsel.go.id / admin123')
}

main()
  .then(async () => {
    await prisma.$disconnect()
  })
  .catch(async (e) => {
    console.error(e)
    await prisma.$disconnect()
    process.exit(1)
  })