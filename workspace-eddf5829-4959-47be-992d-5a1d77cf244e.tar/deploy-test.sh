#!/bin/bash

# Quick Deploy Script for Testing
echo "🚀 Starting quick deployment test..."

# Step 1: Build production
echo "📦 Building production..."
npm run build

# Step 2: Setup production database
echo "🗄️ Setting up production database..."
export NODE_ENV=production
export DATABASE_URL="file:./db/production.db"

mkdir -p db
npx prisma generate
npx prisma db push
npx tsx prisma/seed.ts
npx tsx prisma/sample-agenda.ts

# Step 3: Start production server
echo "🌐 Starting production server..."
echo "📍 Server will run on: http://localhost:3000"
echo "👤 Login dengan: admin@tangsel.go.id / admin123"
echo "⏹️  Stop server dengan: Ctrl+C"
echo ""

npm start