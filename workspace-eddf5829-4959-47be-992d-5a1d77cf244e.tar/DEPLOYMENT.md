# Sistem Informasi Agenda - Deployment Guide

## 🚀 Cara Publish Aplikasi

### Opsi 1: Vercel (Recommended)
```bash
# Install Vercel CLI
npm i -g vercel

# Deploy ke Vercel
vercel --prod

# Setup environment variables di Vercel Dashboard:
# - DATABASE_URL (gunakan PostgreSQL yang disediakan Vercel)
# - NEXTAUTH_URL (domain Anda)
# - NEXTAUTH_SECRET (generate random string)
```

### Opsi 2: Netlify
```bash
# Install Netlify CLI
npm i -g netlify-cli

# Build untuk production
npm run build

# Deploy ke Netlify
netlify deploy --prod --dir=.next
```

### Opsi 3: VPS/Server Sendiri
```bash
# 1. Clone repository
git clone <your-repo-url>
cd agenda-app

# 2. Install dependencies
npm install

# 3. Setup environment
cp .env.production .env.local

# 4. Setup database
./scripts/setup-prod-db.sh

# 5. Build application
npm run build

# 6. Start production server
npm start
```

### Opsi 4: Docker
```bash
# Build Docker image
docker build -t agenda-app .

# Run container
docker run -p 3000:3000 -v $(pwd)/db:/app/db agenda-app
```

## 📋 Checklist Sebelum Deploy

### ✅ Environment Variables
- [ ] DATABASE_URL (PostgreSQL recommended for production)
- [ ] NEXTAUTH_URL (your domain)
- [ ] NEXTAUTH_SECRET (random string)
- [ ] NODE_ENV=production

### ✅ Security
- [ ] Change demo passwords in production
- [ ] Implement proper authentication (bcrypt)
- [ ] Set up HTTPS
- [ ] Configure CORS if needed

### ✅ Performance
- [ ] Enable database indexing
- [ ] Set up CDN for static assets
- [ ] Configure caching headers
- [ ] Monitor with analytics

### ✅ Backup
- [ ] Set up database backups
- [ ] Backup uploaded files
- [ ] Document recovery process

## 🔧 Configuration Files

### package.json scripts sudah disiapkan:
- `npm run build` - Build production
- `npm start` - Start production server
- `npm run lint` - Code quality check

### Environment Variables:
- `.env.production` - Production configuration
- `.env.local` - Local overrides

## 🌐 Domain Setup

### Setelah deploy:
1. Point domain ke deployment server
2. Update NEXTAUTH_URL dengan domain Anda
3. Setup SSL certificate
4. Test semua functionality

## 📊 Monitoring

### Recommended tools:
- **Vercel Analytics** (jika menggunakan Vercel)
- **Google Analytics** untuk user tracking
- **Uptime monitoring** untuk availability
- **Error tracking** (Sentry, Bugsnag)

## 🆘 Troubleshooting

### Common issues:
1. **Database connection** - Check DATABASE_URL
2. **File upload** - Ensure proper permissions
3. **Authentication** - Verify NEXTAUTH_SECRET
4. **Build errors** - Check Node.js version compatibility

### Commands untuk debugging:
```bash
# Check build
npm run build

# Test production locally
npm run start

# Check database
npx prisma studio

# View logs
tail -f server.log
```