#!/bin/bash

# Production Database Setup Script
echo "🗄️ Setting up production database..."

# Create production database directory
mkdir -p db

# Set production environment
export NODE_ENV=production
export DATABASE_URL="file:./db/production.db"

# Generate Prisma client
echo "📦 Generating Prisma client..."
npx prisma generate

# Push schema to production database
echo "🚀 Pushing schema to production database..."
npx prisma db push --schema=./prisma/schema.prisma

# Seed production database with demo data
echo "🌱 Seeding production database..."
npx tsx prisma/seed.ts

# Add sample agendas
echo "📝 Adding sample agendas..."
npx tsx prisma/sample-agenda.ts

echo "✅ Production database setup complete!"
echo "📍 Database location: ./db/production.db"
echo "👥 Demo users created:"
echo "   - Admin: admin@tangsel.go.id / admin123"
echo "   - Walikota: walikota@tangsel.go.id / admin123"
echo "   - Wakil Walikota: wakil@tangsel.go.id / admin123"
echo "   - Sekda: sekda@tangsel.go.id / admin123"