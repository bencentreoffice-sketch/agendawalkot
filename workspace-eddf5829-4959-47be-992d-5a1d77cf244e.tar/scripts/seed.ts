import { db } from '@/lib/db'
import bcrypt from 'bcryptjs'

async function createDemoUser() {
  try {
    const hashedPassword = await bcrypt.hash('admin123', 10)
    
    const user = await db.user.upsert({
      where: { email: 'admin@tangsel.go.id' },
      update: {},
      create: {
        email: 'admin@tangsel.go.id',
        name: 'Administrator',
        password: hashedPassword,
        role: 'sekda'
      }
    })
    
    console.log('Demo user created:', user)
  } catch (error) {
    console.error('Error creating demo user:', error)
  }
}

createDemoUser()