import { db } from '@/lib/db'

async function createDemoData() {
  try {
    // Create demo user with plain password (no hashing for now)
    const user = await db.user.upsert({
      where: { email: 'admin@tangsel.go.id' },
      update: {},
      create: {
        email: 'admin@tangsel.go.id',
        name: 'Administrator',
        password: 'admin123', // Plain password for demo
        role: 'sekda'
      }
    })
    
    console.log('Demo user created:', user.id)

    // Sample agendas
    const sampleAgendas = [
      {
        tanggal: new Date('2024-06-04'),
        waktu: '09:00',
        asalUndangan: 'Dinas Komunikasi dan Informatika',
        kegiatan: 'Rapat Koordinasi Pembangunan Smart City',
        lokasi: 'Ruang Rapat Walikota, Gedung A Lantai 3',
        disposisi: 'walikota',
        keterangan: 'Pembahasan roadmap smart city Tangsel',
        status: 'terjadwal',
        createdBy: user.id
      },
      {
        tanggal: new Date('2024-06-05'),
        waktu: '10:00',
        asalUndangan: 'Bappeda',
        kegiatan: 'Presentasi RPJPD Kota Tangerang Selatan 2025-2045',
        lokasi: 'Auditorium Gedung B',
        disposisi: 'sekda',
        keterangan: 'Presentasi rencana pembangunan jangka panjang',
        status: 'terjadwal',
        createdBy: user.id
      },
      {
        tanggal: new Date('2024-06-03'),
        waktu: '13:00',
        asalUndangan: 'Dinas Pendidikan',
        kegiatan: 'Peresmian Sekolah Adiwiyata',
        lokasi: 'SDN Ciputat 01',
        disposisi: 'wakil-walikota',
        keterangan: 'Peresmian sekolah yang mendapat penghargaan adiwiyata',
        status: 'selesai',
        createdBy: user.id
      },
      {
        tanggal: new Date('2024-06-06'),
        waktu: '14:00',
        asalUndangan: 'Dinas Kesehatan',
        kegiatan: 'Launching Program Vaksinasi Booster',
        lokasi: 'Puskesmas Serpong',
        disposisi: 'walikota',
        keterangan: 'Launching vaksinasi booster untuk masyarakat',
        status: 'terjadwal',
        createdBy: user.id
      },
      {
        tanggal: new Date('2024-06-02'),
        waktu: '11:00',
        asalUndangan: 'Dinas Perhubungan',
        kegiatan: 'Rapat Evaluasi Traffic Light Management',
        lokasi: 'Ruang Rapat Dishub',
        disposisi: 'sekda',
        keterangan: 'Evaluasi sistem pengaturan lalu lintas',
        status: 'dibatalkan',
        createdBy: user.id
      }
    ]

    // Insert sample agendas
    for (const agenda of sampleAgendas) {
      await db.agenda.create({
        data: agenda
      })
    }

    console.log('Sample agendas created successfully')
  } catch (error) {
    console.error('Error creating demo data:', error)
  }
}

createDemoData()